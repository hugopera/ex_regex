import re

with open("registos.txt", "r", encoding="utf-8") as file:
    texto = file.read()

# \d+ apanha o NIF inteiro, mesmo que tenha dígitos a mais ou a menos,
# para depois o fullmatch conseguir dizer se é válido ou não
nifs = re.findall(r"NIF: (\d+)", texto)
todos_validos = True

for i in nifs:
    if re.fullmatch(r"[123568]\d{8}", i):
        print(i, "Válido")
    else:
        print(i, "Inválido")
        todos_validos = False

if todos_validos:
    print("Todos os NIFs têm formato válido")
else:
    print("Existem NIFs inválidos")
