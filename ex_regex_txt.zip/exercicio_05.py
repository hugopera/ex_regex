import re

with open("dados.txt", "r", encoding="utf-8") as file:
    linhas = file.readlines()

with open("extraidos.txt", "w", encoding="utf-8") as file:
    for linha in linhas:
        nome = re.search(r"Nome: ([^,]+)", linha)
        email = re.search(r"Email: ([\w.-]+@[\w.-]+\.[a-zA-Z]{2,})", linha)
        telemovel = re.search(r"Telemóvel: (\d{3}[- ]?\d{3}[- ]?\d{3})", linha)

        if nome and email and telemovel:
            file.write(nome.group(1) + " | " + email.group(1) + " | " + telemovel.group(1) + "\n")
