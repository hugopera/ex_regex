import re

with open("registos.txt", "r", encoding="utf-8") as file:
    linhas = file.readlines()

for linha in linhas:
    # o grupo ( ) apanha só o ano (os 4 dígitos depois da segunda barra)
    data = re.search(r"Data: \d{2}/\d{2}/(\d{4})", linha)

    if data:
        ano = int(data.group(1))

        if ano < 2025:
            print(linha.strip())
