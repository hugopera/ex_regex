import re

with open("dados.txt", "r", encoding="utf-8") as file:
    texto = file.read()

emails = re.findall(r"[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}", texto)

for i in emails:
    print(i)
