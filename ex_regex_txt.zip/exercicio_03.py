import re

with open("dados.txt", "r", encoding="utf-8") as file:
    texto = file.read()

telemoveis = re.findall(r"\d{3}[- ]?\d{3}[- ]?\d{3}", texto)

for i in telemoveis:
    print(i)
