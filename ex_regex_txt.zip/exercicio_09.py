import re

with open("registos.txt", "r", encoding="utf-8") as file:
    texto = file.read()

codigos = re.findall(r"Código Postal: (\d{4}-\d{3})", texto)

for i in codigos:
    print(i)
