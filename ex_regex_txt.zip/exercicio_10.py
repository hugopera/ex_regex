import re

with open("registos.txt", "r", encoding="utf-8") as file:
    texto = file.read()

dominios = re.findall(r"Site: https?://([^/ |\n]+)", texto)

for i in dominios:
    print(i)
