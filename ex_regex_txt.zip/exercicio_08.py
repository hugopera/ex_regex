import re

with open("registos.txt", "r", encoding="utf-8") as file:
    texto = file.read()

datas = re.findall(r"Data: (\d{2}/\d{2}/\d{4})", texto)

for i in datas:
    print(i)
