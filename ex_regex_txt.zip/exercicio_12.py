import re

with open("registos.txt", "r", encoding="utf-8") as file:
    linhas = file.readlines()

with open("resumo.txt", "w", encoding="utf-8") as file:
    for linha in linhas:
        nome = re.search(r"Nome: ([^|]+)", linha)
        nif = re.search(r"NIF: (\d{9})\b", linha)
        data = re.search(r"Data: (\d{2}/\d{2}/\d{4})", linha)
        codigo = re.search(r"Código Postal: (\d{4}-\d{3})", linha)
        site = re.search(r"Site: https?://([^/ |\n]+)", linha)

        if nome and nif and data and codigo and site:
            file.write(nome.group(1).strip() + " | " + nif.group(1) + " | " + data.group(1) + " | " + codigo.group(1) + " | " + site.group(1) + "\n")
