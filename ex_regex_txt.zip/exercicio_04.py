import re

with open("dados.txt", "r", encoding="utf-8") as file:
    texto = file.read()

nomes = re.findall(r"Nome: ([^,\n]+)", texto)

for i in nomes:
    print(i)
