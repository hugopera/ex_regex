import re

with open("registos.txt", "r", encoding="utf-8") as file:
    texto = file.read()

nifs = re.findall(r"NIF: (\d{9})\b", texto)

for i in nifs:
    print(i)
