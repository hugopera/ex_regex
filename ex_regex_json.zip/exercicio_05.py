import re
import json

with open("dados.json", "r", encoding="utf-8") as file:
    pessoas = json.load(file)

validos = []

for pessoa in pessoas:
    email = re.fullmatch(r"[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}", pessoa["email"])
    nif = re.fullmatch(r"[123568]\d{8}", pessoa["nif"])
    telemovel = re.fullmatch(r"\d{3}[- ]?\d{3}[- ]?\d{3}", pessoa["telemovel"])

    if email and nif and telemovel:
        validos.append(pessoa)

with open("validos.json", "w", encoding="utf-8") as file:
    json.dump(validos, file, indent=4, ensure_ascii=False)
