import re
import json

with open("dados.json", "r", encoding="utf-8") as file:
    pessoas = json.load(file)

for pessoa in pessoas:
    if re.fullmatch(r"[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}", pessoa["email"]):
        print(pessoa["email"], "Válido")
    else:
        print(pessoa["email"], "Inválido")
