import json

with open("dados.json", "r", encoding="utf-8") as file:
    pessoas = json.load(file)

with open("nomes_emails.txt", "w", encoding="utf-8") as file:
    for pessoa in pessoas:
        file.write(pessoa["nome"] + " | " + pessoa["email"] + "\n")
