import re
import json

with open("dados.json", "r", encoding="utf-8") as file:
    pessoas = json.load(file)

for pessoa in pessoas:
    if re.fullmatch(r"[123568]\d{8}", pessoa["nif"]):
        print(pessoa["nif"], "Válido")
    else:
        print(pessoa["nif"], "Inválido")
