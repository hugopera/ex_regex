import re
import json

with open("dados.json", "r", encoding="utf-8") as file:
    pessoas = json.load(file)

for pessoa in pessoas:
    dominio = re.sub(r"^https?://(www\.)?", "", pessoa["site"])
    print(dominio.split("/")[0])
